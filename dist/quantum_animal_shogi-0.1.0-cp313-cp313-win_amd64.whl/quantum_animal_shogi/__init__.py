from copy import copy
from functools import lru_cache
from gymnasium.spaces import Box, Dict, Discrete, MultiBinary
from pettingzoo import AECEnv
from sys import stdout

from .quantum_animal_shogi import RawEnvironment


# PettingZooの環境です。

class Environment(AECEnv):
    metadata = {"render_modes": ["human"], "name": "quantum-animal-shogi"}

    def __init__(self, render_mode=None):
        self.raw_env = RawEnvironment()  # メモリ効率を良くしたい場合は、本コードを参考にRawEnvironmentの使用を検討してください。呼び出しが変わるので、面倒だけど……。

        self.render_mode = render_mode
        self.possible_agents = ["agent_0", "agent_1"]

    @lru_cache(maxsize=None)
    def action_space(self, agent):
        return Discrete((4 * 3 + 8) * (4 * 3))

    def close(self):
        pass

    @lru_cache(maxsize=None)
    def observation_space(self, agent):
        return Dict({"observation": Box(low=0, high=1, shape=[4 * 3 + 8, 5 + 2 + 2]), "action_mask": MultiBinary((4 * 3 + 8) * (4 * 3)), "turn": Discrete(1_000)})

    def get_observation(self, raw_observation):
        raw_observation["turn"] = self.turn

        return raw_observation

    def render(self):
        self.raw_env.render(self.turn)
        print()
        stdout.flush()

    def reset(self, seed=None, options=None):
        self.raw_env.reset()

        self.agents = copy(self.possible_agents)
        self.agent_selection = self.agents[0]

        self.turn = 0
        self.observations = dict([
            (self.agents[0], self.get_observation(self.raw_env.observe())),
            (self.agents[1], None)
        ])
        self.rewards = dict(map(lambda agent: (agent, 0), self.agents))
        self._cumulative_rewards = dict(map(lambda agent: (agent, 0), self.agents))
        self.terminations = dict(map(lambda agent: (agent, False), self.agents))
        self.truncations = dict(map(lambda agent: (agent, False), self.agents))
        self.infos = dict(map(lambda agent: (agent, {}), self.agents))

    def observe(self, agent):
        return self.observations[agent]

    def step(self, action):
        if self.terminations[self.agent_selection] or self.truncations[self.agent_selection]:
            self._was_dead_step(action)
            return

        reward = self.raw_env.step(action)
        self.turn += 1

        if self.turn >= 256:  # 手数が閾値を超えた場合です。
            self.observations[self.agents[(self.agents.index(self.agent_selection) + 0) % 2]] = self.get_observation(self.raw_env.observe_turned())

            self.rewards[self.agents[0]] = -0.5
            self.rewards[self.agents[1]] = -0.5

            self.truncations[self.agents[0]] = True
            self.truncations[self.agents[1]] = True

        if reward != 0:  # 勝敗が決定した場合です。
            self.observations[self.agents[(self.agents.index(self.agent_selection) + 0) % 2]] = self.get_observation(self.raw_env.observe_turned())

            self.rewards[self.agents[(self.agents.index(self.agent_selection) + 0) % 2]] =  reward  # noqa: E222
            self.rewards[self.agents[(self.agents.index(self.agent_selection) + 1) % 2]] = -reward

            self.terminations[self.agents[(self.agents.index(self.agent_selection) + 0) % 2]] = True
            self.terminations[self.agents[(self.agents.index(self.agent_selection) + 1) % 2]] = True

        self.observations[self.agents[(self.agents.index(self.agent_selection) + 1) % 2]] = self.get_observation(self.raw_env.observe())

        self._accumulate_rewards()
        self.agent_selection = self.agents[(self.agents.index(self.agent_selection) + 1) % 2]

        if self.render_mode == "human":
            self.render()


def raw_environment_from_observation(observation):
    return RawEnvironment.from_observation(observation["observation"].T)


__all__ = [
    "Environment",
    "raw_environment_from_observation"
]
